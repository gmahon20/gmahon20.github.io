"""Zero-dependency content queue generator. Does not invent product experiences or publish."""
import csv, datetime, pathlib, re
ROOT=pathlib.Path(__file__).resolve().parents[1]
INPUT=ROOT/'content'/'product_queue.csv'
OUT=ROOT/'content'/'drafts'; OUT.mkdir(exist_ok=True)
with INPUT.open(newline='',encoding='utf-8') as f:
    for row in csv.DictReader(f):
        if row['status']!='queued': continue
        slug=re.sub('[^a-z0-9-]','-',row['category'].lower().replace(' ','-')).strip('-')
        target=OUT/f'{datetime.date.today()}-{slug}.md'
        if target.exists(): continue
        target.write_text(f'''# DRAFT — {row['category']} buying guide

**Status:** Needs human research, fact-check, and approval. NOT FOR PUBLICATION.
**Research started:** {datetime.date.today()}
**Potential source:** {row['source_url'] or '[ADD manufacturer or retailer source URL]'}

## Reader's question
Who benefits from {row['category'].lower()}, and who should skip them?

## What to verify
- Manufacturer specs and exact product model
- Price and availability on the day of publication
- Return policy, warranty, and known limitations
- Claims cross-checked against independent evidence

## Suggested structure
1. What this product category does
2. Shopping criteria and tradeoffs
3. Comparison of *verified* named options
4. Who should buy / who should avoid
5. Sources, date checked, and limitations

## Disclosure
If affiliate links are added: "We may earn a commission if you buy through links in this article."
If sponsored: prominently label "Sponsored" and identify sponsor.

## Publication gate
- [ ] No fabricated firsthand testing or testimonials
- [ ] Claims and links verified
- [ ] Affiliate or sponsorship relationship disclosed
- [ ] Final human editorial approval
''',encoding='utf-8')
        print('Draft created:',target.name)

# TrendVault Reviews — $0 launch kit

## What's included
- `index.html`: responsive homepage with editorial, disclosure and partnership sections.
- `reviews/`: three honest research-based buying guides (no invented product endorsements).
- `content/product_queue.csv`: product-category research queue.
- `automation/build_queue.py`: Python 3 standard-library draft generator.
- `content/sponsor_outreach_template.md`: editable sponsor outreach email.
- `.github/workflows/draft-queue.yml`: optional weekly draft generation through GitHub Actions (subject to GitHub's free-tier limits).

## Publish for free
1. Create a free GitHub account and a **public** repository named `trendvault-reviews`.
2. Upload the contents of this folder, including `.github`.
3. In repo Settings → Pages, choose Deploy from a branch, `main`, `/ (root)`; save.
4. Visit the URL GitHub provides. This is a public prototype, not a custom domain.
5. Test the navigation and email button. The partnership button prepares an email without a recipient; add a dedicated business email to the `mailto:` in `index.html` once created.

## Run automation
Run `python3 automation/build_queue.py` locally, or enable the included GitHub Actions workflow. It writes unpublished drafts to `content/drafts/` and does not publish, send messages, scrape sites, or contact companies. Edit `content/product_queue.csv` to add categories. A weekly scheduled GitHub Action creates draft files in the repository; you must review and approve any publication.

## Before monetizing
- Apply for relevant affiliate programs; approval is not guaranteed.
- Select actual products, verify source URLs, pricing, claims, and program link requirements.
- Replace general guides with evidence-based comparisons; don't claim hands-on testing without it.
- Add visible affiliate disclosures near links and clearly label sponsored content.
- Set up a real business contact address and sponsor media kit with genuine traffic statistics.
- Review applicable FTC endorsement guidance, privacy rules, affiliate terms, and tax obligations.
- Do not auto-post fake consumer reviews, mass-send unsolicited sponsorship pitches, or generate fake ratings.

## What is NOT set up
No hosting account, live domain, email account, affiliate account, paid sponsor, payment processor, or external AI API is connected. No earnings are guaranteed. The draft generator uses templates and requires human sourcing and editorial approval.

# Sponsorship outreach — personalized draft

Subject: Product education collaboration with TrendVault Reviews

Hi [name],

I'm building TrendVault Reviews, a new publication focused on practical product buying guides. I noticed [specific verified detail about brand/product].

Would your team be open to discussing a clearly disclosed sponsored product explainer or comparison feature? We maintain editorial control, verify factual claims, and do not promise favorable reviews.

If relevant, I'd be happy to share a proposal and our current audience metrics [only when available].

Best,
[Your name]
TrendVault Reviews

---
Only send individually to relevant contacts; do not invent audience size, reviews, or a prior relationship. Obtain approval before sending.
